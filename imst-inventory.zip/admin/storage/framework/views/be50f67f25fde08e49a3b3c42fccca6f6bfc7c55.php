<div>
    <ul class="navbar-nav bg-gradient-danger sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/">
            
            <div class="sidebar-brand-icon">
                <img src="<?php echo e(asset('templates/login/images/imst-logo.jpeg')); ?>" alt="logo-image" class="brand-image">
            </div>
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider my-0">

        <!-- Nav Item - Dashboard -->
        

        <!-- Divider -->
        <hr class="sidebar-divider">

        <!-- Heading -->
        

        <!-- Nav Item - Pages Collapse Menu -->
        <li class="nav-item active">
            <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true"
                aria-controls="collapsePages">
                <i class="fas fa-fw fa-table"></i>
                <span>Master Data</span>
            </a>
            <div id="collapsePages" class="collapse <?php echo e($show ?? ''); ?>" aria-labelledby="headingPages"
                data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Data</h6>
                    <a class="collapse-item <?php echo e($userActive ?? ''); ?>" href="/admin/users"> <i
                            class="fas fa-fw fa-user"></i> User</a>
                    <a class="collapse-item" href="/admin/product"><i class="fas fa-fw fa-box"></i> Barang</a>
                    <a class="collapse-item" href="/admin/suplier"><i class="fas fa-fw fa-truck"></i> Suplier</a>
                    <a class="collapse-item" href="/admin/buyer"><i class="fas fa-fw fa-users"></i> Pembeli</a>
                    <a class="collapse-item" href="/admin/warehouse"><i class="fas fa-fw fa-warehouse"></i> Gudang</a>
                    <div class="collapse-divider"></div>
                    <h6 class="collapse-header">Aksi:</h6>
                    <a class="collapse-item" href="admin/transaction"><i class="fas fa-fw fa-exchange-alt"></i>
                        Transaksi</a>
                    <a class="collapse-item" href="admin/convert"><i class="fas fa-fw fa-sync-alt"></i> Konversi
                        Barang</a>
                </div>
            </div>
        </li>

        <!-- Nav Item -->
        <li class="nav-item active">
            <a class="nav-link" href="/">
                <i class="fas fa-fw fa-archive"></i>
                <span>Laporan Posisi Barang</span></a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="/">
                <i class="fas fa-fw fa-truck-loading"></i>
                <span>Laporan Mutasi Barang</span></a>
        </li>


        <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>

    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\imst\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>