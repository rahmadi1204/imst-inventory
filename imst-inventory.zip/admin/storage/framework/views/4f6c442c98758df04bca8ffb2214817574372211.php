<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Input PO</h3>
                            <div class="card-tools">
                                <div class="btn btn-light" data-toggle="modal" data-target="#modal-default">
                                    <i class="fa fa-plus"></i> Master Barang
                                </div>
                            </div>
                        </div>

                        <form action="<?php echo e(route('po.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <?php echo $__env->make('components.po_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <div class="card-footer ">
                                <button type="submit" class="btn btn-primary float-right">
                                    Simpan
                                </button>
                                <a href="<?php echo e(route('po')); ?>" class="btn btn-secondary float-right mr-2">
                                    Kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.card -->
            </div>
        </div>
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Barang PO</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table id="tableSearch" class="table table-bordered table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th>No</th>
                                <th>No PO Vendor</th>
                                <th>Tanggal</th>
                                <th>Kode Barang</th>
                                <th>Nama Barang</th>
                                <th>Deskripsi</th>
                                <th>Latest</th>
                                <th>Kuantitas</th>
                                <th>Satuan Harga</th>
                                <th>Mata Uang</th>
                                <th>Jumlah</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                                $total = 0;
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($item->no_po); ?></td>
                                    <td><?php echo e($item->date_po); ?></td>
                                    <td><?php echo e($item->code_product); ?></td>
                                    <td><?php echo e($item->name_product); ?></td>
                                    <td><?php echo e($item->description); ?></td>
                                    <td><?php echo e($item->latest); ?></td>
                                    <td><?php echo e($item->value_product); ?></td>
                                    <td><?php echo e($item->unit_price); ?></td>
                                    <td><?php echo e($item->currency); ?></td>
                                    <td><?php echo e($item->total_amount); ?></td>
                                    <td>
                                        
                                        <div class="btn btn-danger delete-modal" data-toggle="modal"
                                            data-target="#modal-delete-user" data-id="<?php echo e($item->code_product); ?>"
                                            data-name="<?php echo e($item->name_product); ?> Dari PO <?php echo e($item->no_po); ?>"><i
                                                class="fa fa-trash"></i>
                                        </div>
                                        <?php
                                            $total += $item->total_amount;
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <td colspan="10" class="text-center">JUMLAH</td>
                            <td><?php echo e($total); ?></td>
                            <td></td>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
        </div>
    </section>
    
    <form action="<?php echo e(route('master.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="modal-default">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Tambah Master Barang</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group col">
                            <label for="type_product">Tipe Produk</label>
                            <select name="type_product" id="type_product" class="form-control">
                                <option selected disabled>Pilih</option>
                                <?php $__currentLoopData = $typeProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->type_product); ?>">
                                        <?php echo e($item->type_product); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col">
                            <label for="code_product">Kode Produk</label>
                            <input name="code_product" type="text" class="form-control" id="code_product" required>
                        </div>
                        <div class="form-group col">
                            <label for="name_product">Nama Produk</label>
                            <input name="name_product" type="text" class="form-control" id="name_product" required>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
    </form>

    
    <form action="<?php echo e(route('po.destroy')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('components.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/templates/admin')); ?>/plugins/rupiah/jquery.mask.min.js"></script>
    <script src="<?php echo e(asset('/templates/admin')); ?>/plugins/rupiah/terbilang.js"></script>
    <script type="text/javascript">
        function inputTerbilang() {
            //membuat inputan otomatis jadi mata uang
            $('.mata-uang').mask('0.000.000.000', {
                reverse: true
            });

            //mengambil data uang yang akan dirubah jadi terbilang
            var input = document.getElementById("terbilang-input").value.replace(/\./g, "");

            //menampilkan hasil dari terbilang
            document.getElementById("terbilang-output").value = terbilang(input).replace(/  +/g, ' ');
        }
    </script>
    <?php echo $__env->make('scripts.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('scripts.po_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\imst\admin\resources\views/master_data/po/po_create.blade.php ENDPATH**/ ?>