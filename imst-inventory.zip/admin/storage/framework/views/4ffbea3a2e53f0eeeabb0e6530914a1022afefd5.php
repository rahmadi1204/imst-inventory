<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <div class="card-title">
                                <div class="row">
                                    <h4>Daftar PO</h4>
                                </div>
                            </div>
                            <div class="card-tools">
                                <a href="<?php echo e(route('product')); ?>"
                                    class="btn btn-light text-dark
                                 mr-3"> Kembali
                                </a>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="tableSearch" class="table table-bordered table-hover">
                                <thead class="thead-light">
                                    <tr>
                                        <th>NO</th>
                                        <th>NOMOR PO</th>
                                        <th>TANGGAL PO</th>
                                        <th>STATUS</th>
                                        <th>AKSI</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>12-sd1asd</td>
                                        <td>2020-04-12</td>
                                        <td>Selesai</td>
                                        <td>
                                            <a href="<?php echo e(route('pib.page')); ?>" class="btn btn-success">
                                                Data PIB
                                            </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>12-sd1asd</td>
                                        <td>2020-04-12</td>
                                        <td>On Proses</td>
                                        <td>
                                            <div class="btn btn-success">
                                                Data PIB
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('scripts.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imst\admin\resources\views/admin/products/po/po_index.blade.php ENDPATH**/ ?>