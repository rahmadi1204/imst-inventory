<?php if(session()->has('loginOk')): ?>
    <script>
        let timerInterval
        Swal.fire({
            title: 'Login Berhasil!',
            html: '<?php echo e(session()->get('loginOk')); ?>',
            timer: 1000,
            timerProgressBar: true,
            didOpen: () => {
                Swal.showLoading()
                timerInterval = setInterval(() => {
                    const content = Swal.getContent()
                    if (content) {
                        const b = content.querySelector('b')
                        if (b) {
                            b.textContent = Swal.getTimerLeft()
                        }
                    }
                }, 100)
            },
            willClose: () => {
                clearInterval(timerInterval)
            }
        }).then((result) => {
            /* Read more about handling dismissals below */
            if (result.dismiss === Swal.DismissReason.timer) {
                console.log('I was closed by the timer')
            }
        })
    </script>
<?php elseif(session()->has('loginFail')): ?>
    <script>
        Swal.fire({
            position: 'top',
            icon: 'error',
            title: '<?php echo e(session()->get('loginFail')); ?>',
            showConfirmButton: false,
            timer: 2000
        })
    </script>
<?php elseif(session()->has('Ok')): ?>
    <script>
        Swal.fire({
            position: 'top',
            icon: 'success',
            title: '<?php echo e(session()->get('Ok')); ?>',
            showConfirmButton: false,
            timer: 2000
        })
    </script>
<?php elseif(session()->has('Fail')): ?>
    <script>
        Swal.fire({
            position: 'top',
            icon: 'error',
            title: '<?php echo e(session()->get('Fail')); ?>',
            showConfirmButton: false,
            timer: 2000
        })
    </script>
<?php elseif(session()->has('logout')): ?>
    <script>
        Swal.fire({
            position: 'top',
            title: '<?php echo e(session()->get('logout')); ?>',
            showConfirmButton: false,
            timer: 2000
        })
    </script>

<?php endif; ?>
<?php /**PATH C:\laragon\www\imst-inventory\admin\resources\views/components/alert.blade.php ENDPATH**/ ?>