<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo e(config('app.name')); ?></title>

    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('/templates/alert/')); ?>/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('/templates/admin/')); ?>/css/sb-admin-2.css" rel="stylesheet">
    <link href="<?php echo e(asset('/templates/admin/')); ?>/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">
    <img src="<?php echo e(asset('templates/login/images/imst-logo.jpeg')); ?>" alt="logo-image" class="brand-image">
    <div class="container">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Email</th>

                    </tr>
                </thead>
                <tbody>
                    <?php
                        $no = 1;
                    ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->username); ?></td>
                            <td><?php echo e($item->email); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('/templates/admin')); ?>/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo e(asset('/templates/admin')); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('/templates/admin')); ?>/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('/templates/admin')); ?>/js/sb-admin-2.min.js"></script>
    <script src="<?php echo e(asset('/templates/alert')); ?>/sweetalert2/sweetalert2.min.js"></script>

    <!-- Page level plugins -->
    <script src="<?php echo e(asset('/templates/admin')); ?>/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('/templates/admin')); ?>/vendor/datatables/dataTables.bootstrap4.min.js"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\imst\admin\resources\views/pdf/user_pdf.blade.php ENDPATH**/ ?>