<div class="card-body">
    <div class="row">
        <div class="form-group col-md-2">
            <label for="date_ncrv">Tanggal Return</label>
            <div class="input-group date" id="reservationdate" data-target-input="nearest">
                <input name="date_ncrv" type="text" class="form-control datetimepicker-input"
                    data-target="#reservationdate" required value="<?php echo e($ncrv->date_ncrv ?? old('date_ncrv')); ?> " />
                <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
            </div>
        </div>
        <div class="form-group col">
            <label for="no_po">No. Referensi</label>
            <select name="no_po" id="no_po" class="form-control">
                <option selected disabled>Pilih</option>
                <?php $__currentLoopData = $po; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($ncrv)): ?>
                        <?php if($item->no_po == $pib->no_po): ?>
                            <option value="<?php echo e($item->no_po); ?>" name_supplier="<?php echo e($item->vendor_name); ?>"
                                code_po="<?php echo e($item->code_po); ?>" address="<?php echo e($item->vendor_address); ?>" selected>
                                <?php echo e($item->no_po); ?></option>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($item->no_po == old('no_po')): ?>
                        <option value="<?php echo e($item->no_po); ?>" name_supplier="<?php echo e($item->vendor_name); ?>"
                            code_po="<?php echo e($item->code_po); ?>" address="<?php echo e($item->vendor_address); ?>" selected>
                            <?php echo e($item->no_po); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($item->no_po); ?>" name_supplier="<?php echo e($item->vendor_name); ?>"
                            code_po="<?php echo e($item->code_po); ?>" address="<?php echo e($item->vendor_address); ?>">
                            <?php echo e($item->no_po); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col">
            <label for="name_supplier">Vendor</label>
            <input type="hidden" name="code_po" id="code_po">
            <input name="name_supplier" type="text" class="form-control" id="name_supplier"
                value="<?php echo e($ncrv->name_supplier ?? old('name_supplier')); ?>" required>
        </div>
    </div>
    <div class="row">
        <div class="form-group col">
            <label for="name_warehouse">Gudang</label>
            <select name="name_warehouse" id="name_warehouse" class="form-control custom-select">
                <option selected>Pilih</option>
                <?php $__currentLoopData = $warehouse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($ncrv)): ?>
                        <?php if($ncrv->name_warehouse == $item->name_warehouse): ?>
                            <option value="<?php echo e($item->name_warehouse); ?>" address="<?php echo e($item->address_warehouse); ?>"
                                selected>
                                <?php echo e($item->name_warehouse); ?>

                            </option>
                        <?php else: ?>
                            <option value="<?php echo e($item->name_warehouse); ?>" address="<?php echo e($item->address_warehouse); ?>">
                                <?php echo e($item->name_warehouse); ?>

                            </option>
                        <?php endif; ?>
                    <?php else: ?>
                        <option value="<?php echo e($item->name_warehouse); ?>" address="<?php echo e($item->address_warehouse); ?>">
                            <?php echo e($item->name_warehouse); ?>

                        </option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col">
            <label for="way_transport">Via</label>
            <input name="way_transport" id="way_transport" type="text" class="form-control"
                value="<?php echo e($ncrv->way_transport ?? old('way_transport')); ?>" required>
        </div>
    </div>
    
    
    
    
    <table class="table table-bordered" id="productAddRemove">
        <tr>
            <th width="12%">Kode Barang</th>
            <th width="50%">Jenis & Nama Barang</th>
            <th>Jumlah Produk</th>
            <th>Satuan Produk</th>
            <th></th>
        </tr>
        <tr>
            <td>
                <select name="code_product[0]" id="code_product0" class="form-control">
                    <option value="" selected disabled>Pilih</option>
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->code_product); ?>" type="<?php echo e($item->type_product); ?>"
                            name="<?php echo e($item->name_product); ?>">
                            <?php echo e($item->code_product); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
            <input type="text" class="form-control" name="type_product[0]" id="type_product0" readonly hidden>
            <td>
                <input type="text" name="name_product[0]" id="name_product0" class="form-control" readonly>
            </td>
            <td><input type="number" step="0.01" name="qty_product[0]" class="form-control" />
            </td>
            <td>
                <select name="unit_product[0]" id="unit_product" class="form-control">
                    <option value="" selected disabled>Pilih</option>
                    <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->unit); ?>"><?php echo e($item->unit); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
            <td><button type="button" name="add" id="dynamic-pr" class="btn btn-outline-primary"><i
                        class="fa fa-plus"></i></button></td>
        </tr>
    </table>

</div>
<!-- /.card-body -->
<?php /**PATH C:\laragon\www\imst-inventory\admin\resources\views/components/ncr_vendor_form.blade.php ENDPATH**/ ?>