<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card card-primary">
                        <div class="card-header">
                            <div class="card-title">
                                <div class="row">
                                    <h4>Tabel user</h4>
                                </div>
                            </div>
                            <div class="card-tools">
                                <a href="<?php echo e(route('user.create')); ?>"
                                    class="btn btn-light text-dark
                                 mr-3">
                                    <i class="fa fa-plus"></i> User
                                </a>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="tableSearch" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Username</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="data-row">
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo e($user->username); ?></td>
                                            <td><?php echo e($user->role); ?></td>
                                            <td class="d-flex justify-content-md-center">
                                                <a href="<?php echo e(route('user.edit', $user->username)); ?>"
                                                    class="btn btn-success mr-2">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <div class="btn btn-danger delete-modal" data-toggle="modal"
                                                    data-target="#modal-delete-user" data-id="<?php echo e($user->username); ?>"
                                                    data-name="<?php echo e($user->name); ?>"><i class="fa fa-trash"></i></div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="modal fade" id="modal-delete-user">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    <h4>Yakin Hapus Data </h4>
                    <h4 id="data-target-delete-name"></h4>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <form action="<?php echo e(route('user.destroy')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="username" id="data-target-delete-id">
                        <button type="submit" class="btn btn-danger">
                            <i class="fa fa-trash"></i> Hapus
                        </button>
                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('scripts.datatable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).on("click", ".delete-modal", function() {
            const deleteId = $(this).data('id');
            const deleteName = $(this).data('name');
            $("#data-target-delete-id").val(deleteId);
            $("#data-target-delete-name").text(deleteName);
            // As pointed out in comments,
            // it is unnecessary to have to manually call the modal.
            // $('#addBookDialog').modal('show');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\imst\admin\resources\views/admin/users/user_index.blade.php ENDPATH**/ ?>