<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e($title ?? 'Data'); ?></h3>
                            <div class="card-tools">
                                <a href="<?php echo e(route('warehouse.create')); ?>" class="btn btn-primary mr-3">
                                    <i class="fa fa-plus"></i> Warehouse
                                </a>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="tableSearch" class="table table-bordered table-hover nowrap">
                                <thead class="thead-light">
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Kode Gudang</th>
                                        <th>Nama Gudang</th>
                                        <th>Alamat Gudang</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($item->date); ?></td>
                                            <td><?php echo e($item->code_warehouse); ?></td>
                                            <td><?php echo e($item->name_warehouse); ?></td>
                                            <td><?php echo e($item->address_warehouse); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('warehouse.edit', $item->code_warehouse)); ?>"
                                                    class="btn btn-success">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <div class="btn btn-danger delete-modal" data-toggle="modal"
                                                    data-target="#modal-delete-user" data-id="<?php echo e($item->code_warehouse); ?>"
                                                    data-name="<?php echo e($item->name_warehouse); ?>"><i class="fa fa-trash"></i>
                                                </div>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <form action="<?php echo e(route('warehouse.destroy')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('components.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\imst-inventory\admin\resources\views/master_data/gudang/gudang_index.blade.php ENDPATH**/ ?>