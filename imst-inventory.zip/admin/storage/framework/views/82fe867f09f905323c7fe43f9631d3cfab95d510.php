<div class="modal fade" id="modal-delete-user">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center">
                <h4>Yakin Hapus Data </h4>
                <h4 id="data-target-delete-name"></h4>
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <input type="hidden" name="id" id="data-target-delete-id">
                <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i> Hapus
                </button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<?php /**PATH C:\laragon\www\imst-inventory\admin\resources\views/components/delete_modal.blade.php ENDPATH**/ ?>