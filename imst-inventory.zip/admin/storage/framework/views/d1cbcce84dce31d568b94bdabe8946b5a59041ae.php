<script>
    $('#send_address').change(function() {
        let codeSend = $(this).val();
        let addressWarehouse = $('#send_address option:selected').attr("address");

        $("#address_warehouse").val(addressWarehouse);

    });
    $('#vendor_name').change(function() {
        let codeVendor = $(this).val();
        let addressVendor = $('#vendor_name option:selected').attr("address");

        $("#vendor_address").val(addressVendor);

    });
    $('#code_product').change(function() {
        let codeProduct = $(this).val();
        let nameProduct = $('#code_product option:selected').attr("name");
        let typeProduct = $('#code_product option:selected').attr("type");

        $("#name_product").val(nameProduct);
        $("#type_product").val(typeProduct);

    });
    $('#currency').change(function() {
        let codeCurr = $(this).val();
        let symbol = $('#currency option:selected').attr("symbol");

        $(".curr").text(symbol);

    });

    $("#qty_product0, #unit_price0").keyup(function() {
        let jumlah = $("#qty_product0").val();
        let harga = $("#unit_price0").val();
        let total = parseFloat(jumlah) * parseFloat(harga);
        $('#total_amount0').val(total);
    });
    $('#datePO').datetimepicker({
        format: 'Y-M-D'
    });
    $('#latest0').datetimepicker({
        format: 'Y-M-D'
    });
    //Datemask dd/mm/yyyy
    $('#latest0').inputmask('yyyy/mm/dd', {
        'placeholder': 'yyyy/mm/dd'
    })
    let j = 0;
    $("#dynamic-pr").click(function() {
        ++j;
        $("#productAddRemove").append('<tr><td><select name="code_product[' + j +
            ']" id="code_product' +
            j +
            '" class="form-control"><option value="" selected disabled>Pilih</option><?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($item->code_product); ?>" type="<?php echo e($item->type_product); ?>" name="<?php echo e($item->name_product); ?>"><?php echo e($item->code_product); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td><td><div class="input-group"><input type="text" name="type_product[' +
            j +
            ']" class="form-control" id="type_product' + j +
            '"  readonly hidden/><input type="text" name="name_product[' +
            j +
            ']" class="form-control" id="name_product' + j +
            '"  readonly/><input type="text" name="description[' +
            j +
            ']" id="description' +
            j +
            '" class="form-control" hidden></div></td><td><input type="number" name="qty_product[' +
            j +
            ']" id="qty_product' +
            j +
            '" class="form-control" /></td><td><div class="input-group"><div class="input-group-prepend"><span class="input-group-text curr">$</span></div><input name="unit_price[' +
            j +
            ']" type="number" step="0.01" class="form-control" id="unit_price' +
            j +
            '"value="<?php echo e($po->unit_price ?? old('unit_price')); ?>" required></div></td><td><div class="input-group" ><div class="input-group-prepend" ><span class = "input-group-text curr" > $ </span></div> <input name = "total_amount[' +
            j +
            ']"type = "number"class = "form-control mata-uang"id = "total_amount' +
            j +
            '"value="<?php echo e($po->total_amount ?? old('total_amount')); ?>"required readonly ></div></td><td><input type="text" name="latest[' +
            j +
            ']" id="latest' + j +
            '" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy/mm/dd" data-mask></td><td><button type="button" class="btn btn-outline-danger remove-input-product"><i class="fa fa-trash"></i></button></td > < /tr>'
        );
        $('#latest' + j).inputmask('yyyy/mm/dd', {
            'placeholder': 'yyyy/mm/dd'
        })
        $("#qty_product" + j + ", #unit_price" + j).keyup(function() {
            let jumlah = $("#qty_product" + j).val();
            let harga = $("#unit_price" + j).val();
            let total = parseFloat(jumlah) * parseFloat(harga);
            $('#total_amount' + j).val(total);
        });
        $("#code_product" + j).change(function() {
            let code = $(this).val();
            let name = $('#code_product' + j + ' option:selected').attr("name");
            let type = $('#code_product' + j + ' option:selected').attr("type");

            $("#name_product" + j).val(name);
            $("#type_product" + j).val(type);

        });
    });
    $(document).on('click', '.remove-input-product', function() {
        $(this).parents('tr').remove();
    });
    $("#code_product" + 0).change(function() {
        let code = $(this).val();
        let name = $('#code_product' + 0 + ' option:selected').attr("name");
        let type = $('#code_product' + 0 + ' option:selected').attr("type");

        $("#name_product" + 0).val(name);
        $("#type_product" + 0).val(type);

    });
</script>
<?php /**PATH C:\laragon\www\imst-inventory\admin\resources\views/scripts/po_create.blade.php ENDPATH**/ ?>