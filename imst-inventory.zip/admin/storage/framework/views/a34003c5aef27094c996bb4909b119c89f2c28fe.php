<div id="step5-part" class="content" role="tabpanel" aria-labelledby="step5-part-trigger">
    <div class="row">
        
        <div class="form-group col">
            <label for="country_product">Negara Asal Produk</label>
            <input name="country_product" type="text" class="form-control" id="country_product"
                value="<?php echo e($pib->country_product ?? old('country_product')); ?>">
        </div>
        <div class="form-group col">
            <label for="type_pabean">Tipe Pabean</label>
            <input name="type_pabean" type="text" class="form-control" id="type_pabean"
                value="<?php echo e($pib->type_pabean ?? old('type_pabean')); ?>">
        </div>
        <div class="form-group col">
            <label for="date_product">Tanggal Produk</label>
            <div class="input-group date" id="productDate" data-target-input="nearest">
                <input name="date_product" type="text" class="form-control datetimepicker-input"
                    value="<?php echo e($pib->date_product ?? old('date_product')); ?>" data-target="#productDate" />
                <div class="input-group-append" data-target="#productDate" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <table id="productAddRemove" class="table table-bordered table-hover nowrap">
        <thead class="thead-light">
            <tr>
                <th>Pos Tarif Produk, Uraian</th>
                <th>Kode Barang</th>
                <th>Uraian Jenis Barang, Merek, Tipe,Spesifikasi Wajib</th>
                <th>Jumlah Produk</th>
                <th>Satuan Produk</th>
                <th>Berat Bersih Produk</th>
                <th>Jumlah Kemasan Produk</th>
                <th>Satuan Kemasan Produk</th>
                <th>Nilai Pabean</th>
                <th>Add/Delete</th>
            </tr>
        </thead>
        <tr>
            <td><input type="text" name="pos_product[0]" class="form-control" />
            </td>
            <td>
                <select name="code_product[0]" id="code_product0" class="form-control">
                    <option value="" selected disabled>Pilih</option>
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->code_product); ?>" type="<?php echo e($item->type_product); ?>"
                            name="<?php echo e($item->name_product); ?>">
                            <?php echo e($item->code_product); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
            <input type="text" class="form-control" name="type_product[0]" id="type_product0" readonly hidden>
            <td>
                <input type="text" name="name_product[0]" id="name_product0" class="form-control" readonly>
            </td>
            <td><input type="number" step="0.01" name="qty_product[0]" class="form-control" />
            </td>
            <td>
                <select name="unit_product[0]" id="unit_product" class="form-control">
                    <option value="" selected disabled>Pilih</option>
                    <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->unit); ?>"><?php echo e($item->unit); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
            <td>
                <div class="input-group">
                    <input type="number" step="0.01" name="netto_product[0]" class="form-control" />
                    <div class="input-group-appeand">
                        <div class="input-group-text">KG</div>
                    </div>
                </div>
            </td>
            <td><input type="number" step="0.01" name="qty_pack[0]" class="form-control" />
            </td>
            <td><select name="type_pack[0]" id="type_pack" class="form-control">
                    <option value="" selected disabled>
                        Pilih</option>
                    <option value="Pack">Pack</option>
                    <option value="Container">Container</option>
                    <option value="Pallet">Pallet</option>
                </select>
            </td>
            <td><input type="number" step="0.01" name="value_pabean[0]" class="form-control" />
            </td>
            <td><button type="button" name="add" id="dynamic-pr" class="btn btn-outline-primary"><i
                        class="fa fa-plus"></i></button></td>
        </tr>
    </table>
    <div class="btn btn-primary" onclick="stepper.next()">Next</div>
    <div class="btn btn-secondary" onclick="stepper.previous()">Kembali</div>

</div>
<?php /**PATH C:\laragon\www\imst-inventory\admin\resources\views/components/pib_form5.blade.php ENDPATH**/ ?>